from os import getenv

# --------------------------------------------------------
BOT_USERNAME = getenv("BOT_USERNAME", "USERNAME")
